# SaloneTunes — deployable starter

This is a static Netlify website with Supabase authentication, artist dashboard, private audio uploads, track publishing, public catalogue and basic play-count recording.

## Before deploying

1. In Supabase, open the **SaloneTunes** project.
2. Confirm the Storage bucket named `music` exists and is **private**.
3. Open **SQL Editor → New query**.
4. Open `supabase-setup.sql`, copy all its contents into the SQL Editor and press **Run**.
5. In `index.html`, replace:
   - `PASTE_PROJECT_URL_HERE` with the Supabase Project URL.
   - `PASTE_PUBLISHABLE_KEY_HERE` with the Supabase Publishable key (`sb_publishable_...`).
   Use the publishable key only. Never put a secret/service-role key in this file.
6. In Supabase **Authentication → URL Configuration**, set the Site URL to your Netlify site, for example `https://YOUR-SITE.netlify.app`. Add that exact URL to Redirect URLs too.
7. Commit the files to GitHub and deploy the repository on Netlify. For this simple static site, publish directory is the project root and no build command is needed.

## Test

- Open the Netlify URL.
- Create an account with an email you can access.
- Confirm the email using the link sent by Supabase.
- Log in, upload an audio file, then publish it from **Your releases**.
- Open the Music page to see published tracks.

## Important limitations before public launch

- This is an MVP starter, not a finished commercial streaming service.
- Payment collection, subscription renewals, royalty calculations and withdrawals are not active. They require a payment provider available to your business/country, server-side payment verification, admin controls, legal terms and payout procedures. Never trust payment status sent from a browser.
- Play counts are basic event records, not fraud-resistant audited royalty metrics. Do not promise a fixed payment per stream.
- Audio uploads use private storage and signed URLs. The SQL policies allow signed URL creation only for the owner's files or files attached to published tracks. For a high-traffic production service, consider moving signing to a secure server function and adding rate limits.
- Add moderation, copyright takedown procedures, backups, rate limits, file scanning and abuse controls before accepting public uploads.
- Configure email SMTP in Supabase for reliable confirmation emails. The default mail service may have low limits.

## Suggested next production steps

1. Add Netlify/Supabase Edge Functions for secure public playback URLs.
2. Add admin moderation and approval workflow.
3. Integrate a payment provider that supports your registered business and Sierra Leone, using server-side webhooks.
4. Define a transparent royalty formula and minimum payout threshold.
