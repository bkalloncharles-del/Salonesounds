-- SaloneTunes Supabase setup
-- Run this whole file in Supabase Dashboard > SQL Editor > New query > Run.
-- Keep the Storage bucket named "music" PRIVATE.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Artist',
  role text not null default 'artist' check (role in ('artist','listener')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name','Artist'))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.tracks (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  artist_name text,
  genre text,
  description text,
  audio_path text not null,
  cover_path text,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.plays (
  id uuid primary key default gen_random_uuid(),
  track_id uuid not null references public.tracks(id) on delete cascade,
  played_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  plan_name text not null,
  status text not null default 'pending' check (status in ('pending','active','cancelled','expired')),
  provider_reference text,
  started_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.artist_payouts (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(12,2) not null check (amount >= 0),
  currency text not null default 'SLE',
  status text not null default 'pending' check (status in ('pending','approved','paid','rejected')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.tracks enable row level security;
alter table public.plays enable row level security;
alter table public.subscriptions enable row level security;
alter table public.artist_payouts enable row level security;

drop policy if exists "Profiles readable" on public.profiles;
create policy "Profiles readable" on public.profiles for select using (true);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "Published tracks readable" on public.tracks;
create policy "Published tracks readable" on public.tracks for select using (is_published = true or auth.uid() = artist_id);
drop policy if exists "Artists insert own tracks" on public.tracks;
create policy "Artists insert own tracks" on public.tracks for insert with check (auth.uid() = artist_id);
drop policy if exists "Artists update own tracks" on public.tracks;
create policy "Artists update own tracks" on public.tracks for update using (auth.uid() = artist_id) with check (auth.uid() = artist_id);
drop policy if exists "Artists delete own tracks" on public.tracks;
create policy "Artists delete own tracks" on public.tracks for delete using (auth.uid() = artist_id);

drop policy if exists "Play counts can be inserted" on public.plays;
create policy "Play counts can be inserted" on public.plays for insert with check (
  exists (select 1 from public.tracks t where t.id = track_id and t.is_published = true)
);
drop policy if exists "Artists view plays on own tracks" on public.plays;
create policy "Artists view plays on own tracks" on public.plays for select using (
  exists (select 1 from public.tracks t where t.id = track_id and t.artist_id = auth.uid())
);

drop policy if exists "Users view own subscriptions" on public.subscriptions;
create policy "Users view own subscriptions" on public.subscriptions for select using (auth.uid() = user_id);
drop policy if exists "Users request own subscriptions" on public.subscriptions;
create policy "Users request own subscriptions" on public.subscriptions for insert with check (auth.uid() = user_id);

drop policy if exists "Artists view own payouts" on public.artist_payouts;
create policy "Artists view own payouts" on public.artist_payouts for select using (auth.uid() = artist_id);

-- Private Storage bucket policies. Bucket must already exist and be named "music".
drop policy if exists "Authenticated users upload to own folder" on storage.objects;
create policy "Authenticated users upload to own folder" on storage.objects for insert to authenticated
with check (bucket_id = 'music' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Users read own files and public track files" on storage.objects;
create policy "Users read own files and public track files" on storage.objects for select
using (
  bucket_id = 'music' and (
    (auth.uid() is not null and (storage.foldername(name))[1] = auth.uid()::text)
    or exists (
      select 1 from public.tracks t
      where t.is_published = true and (t.audio_path = name or t.cover_path = name)
    )
  )
);
drop policy if exists "Users update own files" on storage.objects;
create policy "Users update own files" on storage.objects for update to authenticated
using (bucket_id = 'music' and (storage.foldername(name))[1] = auth.uid()::text)
with check (bucket_id = 'music' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Users delete own files" on storage.objects;
create policy "Users delete own files" on storage.objects for delete to authenticated
using (bucket_id = 'music' and (storage.foldername(name))[1] = auth.uid()::text);

-- NOTE: Playback of private files requires signed URLs. A production deployment
-- should generate signed URLs server-side after checking that a track is published.
-- Do not make the bucket public just to bypass this security check.
